Tangent
=======

An experimental programming language, focused on the use of type information to infer order of operations and allow cleaner extensible syntax.
Follow the language blog at http://tangent-lang.blogspot.com/
